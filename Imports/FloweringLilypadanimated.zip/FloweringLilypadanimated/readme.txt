Flowering Lilypads - animated
By hellblazer-14

Description:
Hey again guys,

here you have a lilypad with a floating animation and the high def textures from one of the wc3 campaign glue screens (forgot which one XD).
Use it for a small pond or lake, or a calm bend in a river. Works great in any cinematic or map, and takes virtually no space!!!

Credits not required, thank blizzard for the original texture and base ;)
Enjoy.

*edit* made the models material two sided.

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2009, September 1
Model was last updated 2009, September 2


Visit http://www.hiveworkshop.com for more downloads