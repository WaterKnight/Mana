GoldOre
By Ergius

Description:
Hm... What is in that bag, carried by that peasant? This is it. Gold is not just a yellow rock... This pile of gold ore has animated material layer, that looks like shining. Don't look at screenshot! Download the model and check it out!

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2008, July 12


Visit http://www.hiveworkshop.com for more downloads