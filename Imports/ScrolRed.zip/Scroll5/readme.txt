Scroll5

Description:
This is my first from scratch model in a way... made compleatly with oinkerwinkles tool and edited with his tools aswell... This model uses ingame textures...

Skins:
(the skins listed below are not nescessarily in this zip package, they are just a list of the skins used by the model.)Textures\Purple_Star.blp
ReplaceableTextures\CommandButtons\BTNScroll.blp
Textures\Purple_Glow_Dim.blp

Downloaded from http://www.hiveworkshop.com