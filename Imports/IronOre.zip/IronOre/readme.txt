IronOre
By Ergius

Description:
Oh crap! The silver and gold is too fragile to use in armors. There are plently of iron mines here so we can make cheep and tough armor... This is it. Gold and silver are pretty, but not more, and the iron, that is smelted into steel is made for a real tasks... This pile of iron ore hasn't got any shining, since it is not very precious and pretty item. Don't look at screenshot! Download the model and check it out!

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2008, July 12


Visit http://www.hiveworkshop.com for more downloads