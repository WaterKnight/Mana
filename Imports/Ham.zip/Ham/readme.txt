Ham
By RightField

Description:
This model is recommended for use as an item.

Textures:
Objects\InventoryItems\Ham\Ham.blp

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 1969, December 31
Model was last updated 2004, July 2


Visit http://www.hiveworkshop.com for more downloads