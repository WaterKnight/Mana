Potions 1
---------

The paths for the models and skin are:


Items\PotionOfHealing.mdx
Items\PotionOfMana.mdx
Items\PotionOfGreaterHealing.mdx
Items\PotionOfGreaterMana.mdx
Items\PotionOfRejuvenation.mdx
Items\PotionOfInvulnerability.mdx
Items\PotionOfInvisibilty.mdx

Items\Potions1.blp


Potions1.blp is a skin used by all the models, so even if you just have one potion model in your map, this skin must be present.

Created by Xazuki.