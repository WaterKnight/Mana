Pentagram Aura
By Skizzik

Description:
My 2nd model, done in magos again but using an custom texture
 i'm not good with descriptions so enjoy and give credits if use in your map

Textures:
BlueStar.blp

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2008, November 15


Visit http://www.hiveworkshop.com for more downloads