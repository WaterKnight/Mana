Red Boots
By Matarael

Description:
Item model of the Boots of Speed icon. It's basically the same model as the one I used for the Boots of Quelthalas, but altered it to fit this icon. It spins and makes shiny stars.

Shame I can't get the &quot;lightning&quot; bit but I didn't want to add more polygons to the model (to make it as small as I could.

Texture is from the icon, credit me when you use it lol.

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2009, May 27


Visit http://www.hiveworkshop.com for more downloads