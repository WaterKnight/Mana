PotionOmniscence

Description:
Model for the item "Potion of Omniscence".
Uses the icon as texture.

Skins:
(the skins listed below are not nescessarily in this zip package, they are just a list of the skins used by the model.)ReplaceableTextures\CommandButtons\BTNPotionOfOmniscience.blp
Textures\Yellow_Star.blp
Textures\Yellow_Star_Dim.blp
Textures\GenericGlow64.blp

Downloaded from http://www.hiveworkshop.com