PotionManaLesser

Description:
Model for the item "Lesser Mana potion".
Uses texture of the icon.

Skins:
(the skins listed below are not nescessarily in this zip package, they are just a list of the skins used by the model.)ReplaceableTextures\CommandButtons\BTNPotionBlueSmall.blp
Textures\Yellow_Star.blp
Textures\Yellow_Star_Dim.blp
Textures\GenericGlow64.blp

Downloaded from http://www.hiveworkshop.com