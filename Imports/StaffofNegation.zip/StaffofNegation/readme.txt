Staff of Negation
By Thrikodius

Description:
Another attatchment for the Wc3 icons using the icon as a texture. This one was a little more tricky than the claws of attack but I think I managed. A little higher poly, mostly cause of to the glow and the texture (I had to adapt to the icon).

Give credit and please don't edit.

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2009, March 3
Model was last updated 2009, March 3


Visit http://www.hiveworkshop.com for more downloads