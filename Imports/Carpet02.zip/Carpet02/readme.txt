Carpet 02
By Tranquil

Description:
Carpet model that can be used for decoration. There is also blue, purple, green, and yellow carpet. If you like this one i can upload them too.

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2008, October 13
Model was last updated 2008, October 13


Visit http://www.hiveworkshop.com for more downloads