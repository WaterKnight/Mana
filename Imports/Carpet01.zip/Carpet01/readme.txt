Carpet 01
By Tranquil

Description:
Carpet model for decoration in the blue color.

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2008, October 18


Visit http://www.hiveworkshop.com for more downloads