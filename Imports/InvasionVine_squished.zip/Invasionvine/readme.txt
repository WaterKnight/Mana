Invasion vine

Description:
Unit from my Sylvan race.

Invasion vine :Support/Base unit.

The invasion vines are ramification of the Mother root itself.These are pure sylvan unit.And other units born from different breeds can't survive any longer without the invasion vine to provide them the sylvan essence.It transform any vegetaion or fungus into a lively deadly mutant breed.The invasion vine can't fight or defend by itself but is spread a noxious spore in the air.It burns eyes, skin and bronchia when you breathe it.That's why no one can approach or harms the Mother roots since you have to travel throught a huge and unpenetrable forest of these things and others to reache it.

Skins:
(the skins listed below are not nescessarily in this zip package, they are just a list of the skins used by the model.)Buildings\NightElf\EntangledGoldmine\LightRoots.blp
Textures\CloudSingle.blp
Textures\Green_Star.blp

Downloaded from http://www.hiveworkshop.com