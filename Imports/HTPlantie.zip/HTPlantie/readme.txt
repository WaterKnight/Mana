HTPlantie
By HappyTauren

Description:
A simple plant, I wanted to texture something, so I made a quick model.... smart eh.

Textures:
HTPlantie.blp

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2008, December 4


Visit http://www.hiveworkshop.com for more downloads