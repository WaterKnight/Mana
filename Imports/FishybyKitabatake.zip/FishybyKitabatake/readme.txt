Fishy
By Kitabatake

Description:
A Fish attachment model


Uses in game textures

Give credits if you use it

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2008, June 29


Visit http://www.hiveworkshop.com for more downloads