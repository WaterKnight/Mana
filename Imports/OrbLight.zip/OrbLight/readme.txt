Orb of Light
By General Frank

Description:
Mesh (Sphere) was made in Milkshape3D.
Have fun with it.

[COLOR=&quot;Red&quot;][B][SIZE=&quot;3&quot;]Give credits if you use it in your campaign/map, DON'T distribute to other sites and DON'T edit without my permission.
Have fun with the model.[/SIZE][/B][/COLOR]

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2008, November 2


Visit http://www.hiveworkshop.com for more downloads