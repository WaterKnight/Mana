Cheese
By D.O.G.

Description:
This is cheese item. Made from boredom.

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2008, August 20


Visit http://www.hiveworkshop.com for more downloads