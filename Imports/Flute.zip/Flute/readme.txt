Staff
By Matarael

Description:
The flute. Or because of DotA, it's more commonly known as the &quot;quarterstaff&quot;.

Honestly I feel like cheating by submitting this model. It's a bloody cylinder with the icon as texture. The stars and animation is from the other objects I made. Took me 20 minutes to &quot;make&quot; this one. But it needed to be made so here it is.

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2009, June 14


Visit http://www.hiveworkshop.com for more downloads