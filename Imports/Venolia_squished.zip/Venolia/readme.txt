Venolia

Description:
Unit from my Sylvan race.

Venolia :Light ranged unit

The Sylvan essence usualy give to common flowers the abilities  to spit a lethal poison.These are called Venolia though it regroup a multitude of breeds.

Skins:
(the skins listed below are not nescessarily in this zip package, they are just a list of the skins used by the model.)Buildings\NightElf\AncientProtector\AncientProtector.blp
Textures\Ruins_PlantLife.blp
ReplaceableTextures\RuinsTree\RuinsTree.blp
Textures\Green_Glow3.blp

Downloaded from http://www.hiveworkshop.com