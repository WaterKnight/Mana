Charlie the Unicorn
By larchrono

Description:
[youtube]http://www.youtube.com/watch?v=CsGYh8AacgY[/youtube]

Charlie is the leading character in this video :D

It's so interesting that I spend some time making this model :)

Textures:
Charlie.blp

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2009, September 16
Model was last updated 2009, September 20


Visit http://www.hiveworkshop.com for more downloads