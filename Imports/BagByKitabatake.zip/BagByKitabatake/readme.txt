Bag Item
By Kitabatake

Description:
A bag item model

Uses in game textures

Give credits if you use it

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2008, June 28


Visit http://www.hiveworkshop.com for more downloads